import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import session from 'express-session'; // <--- NECESARIO: Instálalo si no lo tienes (npm install express-session)
import routes from './routes.js';
import connectDB from './config/db.js';
import passport from 'passport';
import "./config/passport.js";
import cookieParser from 'cookie-parser';

connectDB();

const app = express();

// ...
app.use(cookieParser()); // <--- Agrega esto
app.use('/api', routes);

// --- 1. CONFIGURACIÓN CRÍTICA PARA AWS ---
// Esto le dice a Express que confíe en que API Gateway/Elastic Beanstalk manejan el HTTPS
app.set('trust proxy', 1);

// --- 2. CORS CON CREDENCIALES ---
app.use(cors({
  // Pon aquí la URL exacta de tu frontend en Amplify (sin barra al final)
  origin: process.env.CLIENT_URL || "https://main.dwne0zj9fti75.amplifyapp.com",
  credentials: true, // <--- OBLIGATORIO: Permite que pasen las cookies
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}));

app.use(express.json());

// --- 3. CONFIGURACIÓN DE LA COOKIE (SOLUCIÓN AL SESSION EXPIRED) ---
app.use(session({
  secret: process.env.SESSION_SECRET || 'tu_secreto_super_seguro',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: true,       // <--- OBLIGATORIO: true porque usas HTTPS (API Gateway)
    sameSite: 'none',   // <--- OBLIGATORIO: 'none' permite cookies entre dominios distintos
    httpOnly: true,     // Seguridad: JS no puede leer la cookie
    maxAge: 24 * 60 * 60 * 1000 // 1 día de vida
  }
}));

app.use(passport.initialize());
app.use(passport.session()); // <--- Necesario para que Passport guarde el usuario en la sesión

app.disable('x-powered-by');

const PORT = process.env.PORT || 3000;

app.use('/api', routes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});