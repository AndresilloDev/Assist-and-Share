import jwt from "jsonwebtoken";
import { ApiError } from "../utils/ApiError.js";

export const authMiddleware = (roles) => {
    return (req, res, next) => {
        // 1. Prioridad: Buscar token en Cookies (Navegador)
        let token = req.cookies && req.cookies.token;

        // 2. Respaldo: Buscar token en Headers (Postman / Mobile)
        if (!token) {
            const authHeader = req.headers["authorization"];
            token = authHeader?.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;
        }

        if (!token) {
            return ApiError.unauthorized(res, "Usuario no autenticado");
        }

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            // 3. Mantenemos tu estructura de req.session para no romper controladores existentes
            // Aunque Express no use sesiones, simulamos el objeto para compatibilidad
            req.session = req.session || {};
            req.session.user = { id: decoded.id, role: decoded.role };

            // También es buena práctica tener req.user disponible
            req.user = { id: decoded.id, role: decoded.role };

            if (roles && !roles.includes(req.session.user.role)) {
                if (process.env.DEBUG === "true") {
                    console.warn(`Acceso denegado para el rol: ${req.session.user.role}`);
                }
                return ApiError.forbidden(res, "Acceso denegado");
            }
            next();
        } catch (err) {
            return ApiError.unauthorized(res, "Token inválido o expirado");
        }
    };
};